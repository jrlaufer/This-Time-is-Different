


***Title: Youth & Guns****
***Author: Jill Laufer***
***Date: January 9, 2024***
***Purpose: CCES Data 2014 & 2018 - Coarsened Matching***
***Using cumulative_2006-2022 datasets

**----------------------------------------------------------**

//Matching variables using 2014 and 2018 CES datasets

//these are the same names across the two sets

//main matching variables (using: cumulative_2006-2022)

** education (educ)
** gender (gender)
** race (race)
** partisanship (pid3_leaner)
** ideology (ideo5)
** news interest (newsint)
** citizenship (citizen)
** family income (faminc)
** age (age)

///Used for matching 
*weights (weight_cumulative)

//Merged in by case id
** internet at home (internethome)

///gun opinion variables to merge in 

//change to "backgrchks"
** 2014: CC14_320a  = Background checks 
** 2018: CC18_320a  = Background checks 

//change to "assaultrifban"

** 2014: CC14_320d  = Assault rifle ban
** 2018: CC18_320c  = Assault rifle ban

//change to "agconceal"
** 2014: CC14_320e  = Against conceal carry
** 2018: CC18_320d  = Against conceal carry


//voting variables

**vv_turnout_gvm: Validated turnout General Election
**vv_regstatus: Validated registration status


/////////// Transform 2014 variables /////////////


cd "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching"



//read in ces 2014
use "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/CCES14_clean.dta"

//transform column 1 to case id
rename V101 case_id

//format gun variables
//** Gun Var. 1 | for backgrounds checks
tab CC14_320a 
gen backgrchks=0
replace backgrchks=1 if CC14_320a==1
tab backgrchks

//** Gun Var. 2 | ban assault rifles
tab CC14_320d
gen assaultrifban=0
replace assaultrifban=1 if CC14_320d==1
tab assaultrifban

//** Gun Var. 3 | against conceal carry
tab CC14_320e
gen agconceal=0
replace agconceal=1 if CC14_320e==2
tab agconceal

gen year=2014
gen treat=0

/////////// Transform 2014 and 2018 variables /////////////


cd "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching"



//read in ces 2014
use "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/CCES14_Common_Content_Validated.dta"

//transform column 1 to case id
rename V101 case_id

//format gun variables
//** Gun Var. 1 | for backgrounds checks
tab CC14_320a 
gen backgrchks=0
replace backgrchks=1 if CC14_320a==1
tab backgrchks

//** Gun Var. 2 | ban assault rifles
tab CC14_320d
gen assaultrifban=0
replace assaultrifban=1 if CC14_320d==1
tab assaultrifban

//** Gun Var. 3 | against conceal carry
tab CC14_320e
gen agconceal=0
replace agconceal=1 if CC14_320e==2
tab agconceal

gen year=2014
gen treat=0

//save transformed file:

save "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/CCES14_clean.dta", replace


//read in ces 2018
clear
use "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/cces18_common_vv.dta"

//transform column 1 to case id
rename V101 case_id

//format gun variables
//** Gun Var. 1 | for backgrounds checks
tab CC18_320a 
gen backgrchks=0
replace backgrchks=1 if CC18_320a==1
tab backgrchks

//** Gun Var. 2 | ban assault rifles
tab CC18_320c
gen assaultrifban=0
replace assaultrifban=1 if CC18_320c==1
tab assaultrifban

//** Gun Var. 3 | against conceal carry
tab CC18_320d
gen agconceal=0
replace agconceal=1 if CC18_320d==2
tab agconceal

gen year=2018
gen treat=1

//save transformed file:

save "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/CCES18_clean.dta", replace


//read in Cleaned 2014 files


append using  "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/CCES18_clean.dta"

save "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/CCES14+18_clean.dta", replace


//read in cumulative_2006-2022
clear
use "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/2006-2022 CumlContent CES/2006-2022 CumContent/cumulative_2006-2022.dta"

//merge in 2014-2018

cd "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching"

merge m:1 case_id using "CCES14and18_clean.dta"

drop _merge

//Delete all non used colums (TBD)


//drop years
//drop all years but 2014 and 2018

drop if year == 2006
drop if year == 2007
drop if year == 2008
drop if year == 2009
drop if year == 2010
drop if year == 2011
drop if year == 2012
drop if year == 2013
drop if year == 2015
drop if year == 2016
drop if year == 2017
drop if year == 2019
drop if year == 2020
drop if year == 2021
drop if year == 2022


//Voting variables
codebook vv_turnout_gvm

//Voting
gen voted=0
replace voted=1 if vv_turnout_gvm == 1
tab voted

//Registration
codebook vv_regstatus

gen registered=0
replace registered=1 if vv_regstatus == 1
replace registered=1 if vv_regstatus == 6
tab registered

//MFOL county variable
//convert to numeric

gen county_fips_num = real(county_fips)
list county_fips county_fips_num in 1/5

*gen county_fips_s = encode county_fips

egen MFOL_CNTY = anymatch(county_fips_num), values(17031, 29510, 20209, 31055, 19193, 19113, 55105, 55025, 12011, 55079, 12086, 27123, 27053, 12086, 27123, 28081, 29047, 12015, 38085, 12115, 38015, 12099, 12011, 12057, 19049, 12009, 13145, 12095, 48029, 48141, 12103, 35001, 12097, 8005, 12103, 8031, 49035, 12127, 32003, 6037, 6037, 6059, 6001, 12001, 12031, 12073, 13121, 12005, 13121, 12033, 45019, 1073, 37081, 1101, 51121, 28049, 51003, 22033, 51059, 22071, 11001, 24005, 42101, 42017, 34027, 36047, 36081, 9001, 4013)


//if treatment/year combo is treatment
gen treat=0
replace treat=1 if MFOL_CNTY==1 & year==2018
tab treat

///age

gen under30=0
replace under30 = 1 if age < 30 
tab under30

bysort year: tab voted treat, col chi

bysort voted: tab voted MFOL_CNTY, col chi

alpha backgrchks assaultrifban agconceal

//save merged  file:

save "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/CCES14and18_merged2.dta", replace



**--------------------**



//save merged MFOL file:

save "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/CCES14and18_MFOLonly.dta", replace


**--------------------**

//version with immigration status dropped - they dont vote

codebook citizen
drop if citizen==2
drop if citizen==.


save "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching/CCES14and18_merged4.dta", replace


//unmatched set summary statistics


summary voted year under30 i.race educ gender faminc

bysort voted: tab race educ, col

tab race

tab voted race

logistic voted treat

logistic voted treat c.age i.educ i.pid3_leaner gender i.ideo5 i.race i.newsint i.internethome backgrchks  assaultrifban agconceal faminc

logistic voted treat##(c.age i.educ i.pid3_leaner gender i.ideo5 i.race i.newsint i.internethome backgrchks  assaultrifban agconceal faminc)

logit voted treat##(c.age i.educ i.pid3_leaner gender i.ideo5 i.race i.newsint i.internethome backgrchks assaultrifban agconceal faminc)


quietly margins i.treat, at(age ==(18(7)80)) vsquish
marginsplot, title("2018 Voted over Age, by Treatment") ytitle("Pred. Prob. of Voting") yscale (range(0.2 1)) ylabel(0.2(0.1)0.9) yline(.2)  graphregion(color(white)) bgcolor(white) recast(line) legend(off) recastci(rarea) 


quietly margins i.treat, vsquish
marginsplot, title("2018 Voted over NewsInt, by Treatment") ytitle("Pred. Prob. of Voting") yscale (range(0.2 1)) ylabel(0.2(0.1)0.9) yline(.2)  graphregion(color(white)) bgcolor(white) recast(line) legend(off) recastci(rarea) 





age + educ + gender + race + ideo5 + pid3_leaner + faminc + internethome + newsint + backgrchks + assaultrifban + agconceal + st


//USED THIS ONE for PLOT!!!!
quietly margins assaultrifban, at(age ==(18(7)60)) vsquish
marginsplot, title("2018 Validated Vote over Age, by Assault Rifle Ban support") ytitle("Pred. Prob. of Validated Vote") yscale (range(0.3 1)) ylabel(0.3(0.1)0.9) yline(.3)  graphregion(color(white)) bgcolor(white) recast(line) legend(off) recastci(rarea) 
//assault weapons - no interactions

