


***Title: MFOL PAPEr updates****
***Author: Jill Laufer***
***Updated: NOVEMBER 17, 2025
***Purpose: CES 2018 dataset FIPS corrections (data precleaned***
**----------------------------------------------------------**





CES18_merged1.dta
##"CCES18_MFOL-MatchingPaper.dta"

**--------------------**

////This dataset is already cleaned and tranformed variables - updating the FIPS codes

gen under30=0
replace under30 = 1 if age < 30 
tab under30

drop if missing(countyfips)

//convert to numeric

gen countyfips_num = real(countyfips)
list countyfips countyfips_num in 1/5

**gen countyfips_s = encode countyfips
encode countyfips, gen(countyfips_s)

egen MFOL_CNTY = anymatch(countyfips_num), values(17031, 29510, 20209, 31055, 19193, 19113, 55105, 55025, 12011, 55079, 12086, 27123, 27053, 12086, 27123, 28081, 27027, 12015, 38085, 12115, 38015, 12099, 12011, 12057, 48113, 12009, 48201, 12095, 48029, 48141, 12103, 35001, 12097, 8005, 12103, 8031, 49035, 12127, 32003, 6037, 6037, 6059, 06001, 12001, 12031, 12073, 13121, 12005, 13121, 12033, 45019, 1073, 37081, 1101, 51121, 28049, 51003, 22033, 51059, 22071, 11001, 24005, 42101, 42017, 34027, 36047, 36081, 9001, 01047, 12105)

cd "/Users/mac/Library/CloudStorage/Box-Box/Youth and Gun Violence Projects/Am. Youth and Gun Issues Paper/Coarsened_matching"

save "MFOL_Paper_2018CES_cleaned.dta", replace

**drop if MFOL_CNTY == 0















